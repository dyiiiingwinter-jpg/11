(() => {
  "use strict";

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const STORAGE_KEY = "resume-workbench-local-v3";

  const defaultTemplate = `
    <div class="resume-head jd-head">
      <div><h1>代盈盈</h1><p class="contact">18216688686｜Daingng@163.com</p><p class="contact">现居地：北京｜2001.10</p></div>
      <img class="avatar" src="assets/image1.jpeg" alt="个人证件照">
    </div>
    <section>
      <h2>教育背景</h2>
      <div class="line"><b>中国政法大学</b><strong>硕士｜马克思主义基本原理｜GPA 4.56，专业前5%</strong><span>2024.09—至今</span></div>
      <p class="sub">荣誉：新生奖学金、学业奖学金；持续开展AI算法治理与技术伦理研究，保持跨学科学习与独立思考</p>
      <div class="line"><b>中国政法大学</b><strong>本科｜思想政治教育｜GPA 4.58，专业前15%</strong><span>2020.07—2024.09</span></div>
      <p class="sub">荣誉：北京市优秀毕业论文、二等学业奖学金、校级三好学生、优秀团员</p>
    </section>
    <section>
      <h2>实习经历</h2>
      <div class="line"><b>中国免税品（集团）有限责任公司</b><strong>商品计划部（奢侈品组）实习生</strong><span>2025.07—2025.10</span></div>
      <p class="bullet">【零售经营与业务分析】使用DSS、CIBO跟踪20+国际品牌、3,000+ SKU的销售、库存、价格及生命周期状态，独立输出周/月度经营简报，识别畅滞销、库存变化和异常数据，为商品及门店运营提供依据。</p>
      <p class="bullet">【收入成本与价格测算】参与1,000+ SKU毛利、Margin/IMU及DFS Price测算；搭建万宝龙350+SKU调价分析表，比较零售价、采购价、市场价差及毛利变化，为价格方案评估和经营决策提供可追溯数据。</p>
      <p class="bullet">【供应链履约与协同】全英对接香港CDFI团队及品牌方，日均处理10+英文邮件、完成100+项商品信息同步；协调买手、供应商、履约、财务、物流、仓库及门店，推进建档、上线、付款、清关、入库和异常处理。</p>
      <div class="line"><b>明基（BenQ）智能科技有限公司</b><strong>市场营销 / Marcom 实习生</strong><span>2024.08—2025.07</span></div>
      <p class="bullet">【用户洞察与营销增长】围绕亲子、教育及阅读圈层研究用户画像、内容偏好和消费能力，筛选并对接160+位KOL，其中60%为10万+粉丝达人；维护270+条KOL/KOC资源记录，为渠道选择与复投提供依据。</p>
      <p class="bullet">【电商转化与策略迭代】输出产品Brief并审核150+条内容，持续跟踪阅读、互动、评论和转化表现；针对“种草强、团购转化不足”拆分达人角色及内容链路，累计曝光500万+，推动相关产品环比转化提升40%。</p>
      <p class="bullet">【项目统筹与用户体验】参与联名上市、书友圈层及双11/双12/618项目，拆解预热、官宣、互动和转化节点；搭建9周书友活动时间轴，跟进投稿审核、打卡、用户私信、物料寄送和复盘，协调内容、设计、达人及电商渠道落地。</p>
      <div class="line"><b>中智管理咨询有限公司</b><strong>项目助理实习生</strong><span>2025.11—2026.03</span></div>
      <p class="bullet">【to G咨询与业务拆解】参与10+个国企组织与岗位咨询项目及20+个薪酬绩效项目，梳理组织架构、部门职责、业务流程及指标口径；开展政策、行业和对标研究，识别客户需求、关键问题及优化方向。</p>
      <p class="bullet">【数据分析与方案交付】参与新疆油田人工成本专题研究，协助搭建生产经营与人工成本25项指标体系，整理2015—2023年趋势数据并对标16家单位；输出项目PPT、研究报告和客户方案，支持并行项目、阶段汇报及版本管理。</p>
    </section>
    <section>
      <h2>项目经历</h2>
      <div class="line"><b>中国政法大学研究生创新实践项目</b><strong>项目负责人</strong><span>2026.03—至今</span></div>
      <p class="bullet">【AI议题研究与快速学习】主持校级创新项目，围绕AI算法治理、技术伦理、劳动替代及主体自由完成中英文文献调研、问题界定、研究框架和路线设计，整理30+典型案例并形成阶段报告。</p>
      <p class="bullet">【研究设计与复盘迭代】从技术机制、用户行为和社会影响三个维度比较经典文本、前沿研究及案例证据；依据阶段发现验证并修正研究假设，将复杂新议题拆解为可执行的研究任务和阶段成果。</p>
      <div class="line"><b>北京高校中国特色社会主义理论研究协同创新中心项目</b><strong>课题主要参加者</strong><span>2021.09—2022.09</span></div>
      <p class="bullet">【研究分析与质量控制】完成100+页政策、文献及案例资料整理，按主题、来源和核心观点建立材料结构；协助汇总资料、核对校订文本。</p>
      <div class="line"><b>北京华侨科技创业者协会“新时代青年说”</b><strong>核心参加者</strong><span>2021.12—2022.01</span></div>
      <p class="bullet">【从0-1项目与用户反馈】围绕社会议题完成选题、脚本、制作、发布和复盘，参与产出15条短视频，单条最高获赞1.2万+；依据互动及评论反馈调整内容方向，1个月内推动账号粉丝增长约200%。</p>
    </section>
    <section>
      <h2>校园经历</h2>
      <div class="line"><b>中国政法大学国际处</b><strong>项目科学生助理</strong><span>2026.03—2026.07</span></div>
      <p class="bullet">【业务信息与项目管理】维护300+所海外合作院校信息库，核对学校、地区、合作类型及联系方式；审核归档30+份MOU、Erasmus+等项目。</p>
      <p class="bullet">【信息提炼与客户指引】编辑并发布10+项暑期学校和国际交流通知，提炼申请条件、材料清单、时间节点及咨询方式；翻译并核对海外院校及国际组织材料，降低信息获取成本并支持跨文化项目沟通。</p>
      <div class="line"><b>中国政法大学马克思主义学院学生会</b><strong>分管主席（外联方向）</strong><span>2022.05—2023.05</span></div>
      <p class="bullet">【活动统筹与团队协作】统筹元旦晚会、微视频大赛等12+场活动，将目标拆解为传播、人员、资源和现场节点，覆盖300+师生；依据反馈优化公众号选题与发布节奏，推动单日阅读量由1,000+提升至5,000+、粉丝增长40%。</p>
      <p class="bullet">【商务拓展与资源整合】主动对接校内外资源并推进10+项商家合作，完成询价、需求沟通、合作确认和执行验收，争取资金物料支持5K+。</p>
    </section>
    <section>
      <h2>技能证书</h2>
      <p class="bullet">【商业与运营能力】零售经营、用户洞察、内容与活动运营、电商转化、to G咨询、商务拓展、供应链履约及跨团队项目推进</p>
      <p class="bullet">【数据与AI工具】Excel（数据透视表/VLOOKUP/XLOOKUP）、BI（DSS、CIBO）、基础SQL；使用ChatGPT辅助资料整理、内容构思和文本优化，并进行事实复核</p>
      <p class="bullet">【办公与表达能力】PPT方案及汇报材料、运营分析、项目台账、会议纪要和版本管理；CET-6 517，可使用英语处理商务邮件和跨团队协作</p>
      <p class="bullet">【内容与综合技能】用户及行业研究、多源信息验证；Photoshop、Premiere、Final Cut Pro、iMovie、剪映，可完成图片和视频基础制作</p>
    </section>
    <section>
      <h2>自我评价</h2>
      <p class="bullet">【客户为先与业务意识】零售经营、科技营销和咨询经历，能从消费者、品牌方、门店及客户视角识别需求，结合销售、库存、成本、内容及反馈数据提出建议。</p>
      <p class="bullet">【好奇心与快速学习】先后进入免税零售、消费科技、管理咨询和国际合作等不同场景，能够快速理解业务流程、搭建工作台账并通过阶段复盘沉淀可复用方法。</p>
      <p class="bullet">【担当执行与抗压协作】具有品牌方、供应商、履约、财务、物流、达人及多部门协作经验，能够拆解任务、跟踪节点、处理异常，在多项目并行下保持交付质量。</p>
      <p class="bullet">【岗位匹配】对零售、科技、物流及to C/to B/to G业务有持续兴趣，认同以客户体验、经营结果和履约效率创造长期价值；愿意从客服、物流等一线轮岗深入理解业务全流程，并在实践中承担责任、持续创新。</p>
    </section>`;

  const termGroups = {
    "内容策划": ["内容策划", "内容创作", "选题", "文案", "撰写", "稿件"],
    "品牌传播": ["品牌", "传播", "公关", "品牌调性", "产品传播"],
    "新媒体运营": ["新媒体", "短视频", "公众号", "社媒", "KOL", "KOC"],
    "用户洞察": ["用户洞察", "用户研究", "人群", "需求", "TA"],
    "活动策划": ["活动", "策划", "落地", "社群", "运营"],
    "数据复盘": ["数据", "传播效果", "复盘", "优化", "转化"],
    "跨团队协作": ["协作", "跨团队", "设计", "运营", "公关", "沟通"],
    "信息整合": ["信息检索", "内容整合", "研究", "资料", "框架"],
    "AI 工具": ["AI", "ChatGPT", "人工智能", "辅助写作"],
    "工具技能": ["Excel", "SQL", "Python", "Photoshop", "Figma", "剪映"],
    "资质要求": ["本科", "硕士", "证书", "英语", "CET", "年经验", "年以上"]
  };

  const state = loadState();
  let selectionRange = null;
  let lastAnalysis = { keywords: [], matched: [], missing: [], groups: [], score: 0 };
  let activeVersionId = null;
  let docxTemplateModel = null;
  let jdOptimizationTimer = null;

  function loadState() {
    const seed = {
      templates: [{ id: "tpl-default", name: "京东综合方向管培生定向简历", type:"docx", sourceBase64:window.DEFAULT_DOCX_BASE64, html: defaultTemplate, originalHtml: defaultTemplate, updatedAt: new Date().toISOString() }],
      activeTemplateId: "tpl-default",
      versions: [],
      profile: {
        basic: { name: "代盈盈", phone: "18216688686", email: "Daingng@163.com", city: "北京", intention: "内容策划", years: "" },
        education: [
          { school:"中国政法大学", degree:"硕士", major:"马克思主义基本原理", time:"2024.09—至今", detail:"GPA 4.56，专业前 5%" },
          { school:"中国政法大学", degree:"本科", major:"思想政治教育", time:"2020.07—2024.09", detail:"GPA 4.58，专业前 15%" }
        ],
        work: [],
        projects: [],
        skills: [],
        certificates: [],
        evaluation: ""
      },
      materials: window.DEFAULT_MATERIALS || [],
      draft: { company: "百度", role: "内容策划", jd: "" }
    };
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
      const result = saved ? { ...seed, ...saved, profile: { ...seed.profile, ...(saved.profile || {}) } } : seed;
      ensureTemplateWorkspaces(result);
      return result;
    } catch { return seed; }
  }

  function clone(value) { return JSON.parse(JSON.stringify(value)); }
  function blankProfile() {
    return { basic:{name:"",phone:"",email:"",city:"",intention:"",years:""}, education:[],work:[],projects:[],skills:[],certificates:[],evaluation:"" };
  }
  function ensureTemplateWorkspaces(target) {
    target.templates.forEach((template,index) => {
      if (!template.workspace) template.workspace = {
        userName:index === 0 ? (target.profile?.basic?.name || "代盈盈") : "",
        profile:index === 0 ? clone(target.profile) : blankProfile(),
        materials:index === 0 ? clone(target.materials || window.DEFAULT_MATERIALS || []) : [],
        versions:index === 0 ? clone(target.versions || []) : [],
        draft:index === 0 ? clone(target.draft || {company:"",role:"",jd:""}) : {company:"",role:"",jd:""},
        interview:[]
      };
    });
    activateWorkspaceData(target, target.activeTemplateId);
  }
  function activateWorkspaceData(target, id) {
    const template = target.templates.find(t => t.id === id) || target.templates[0];
    const w = template.workspace;
    target.profile = w.profile; target.materials = w.materials; target.versions = w.versions; target.draft = w.draft;
  }
  function syncWorkspace() {
    const template = currentTemplate();
    if (!template?.workspace) return;
    template.workspace.profile = state.profile;
    template.workspace.materials = state.materials;
    template.workspace.versions = state.versions;
    template.workspace.draft = { company:$("#targetCompany")?.value || "", role:$("#targetRole")?.value || "", jd:$("#jdInput")?.value || "" };
  }

  function persist(message = "已自动保存") {
    const editor = $("#resumeEditor");
    const template = state.templates.find(t => t.id === state.activeTemplateId);
    if (editor && template) {
      template.html = editor.innerHTML;
      template.updatedAt = new Date().toISOString();
    }
    state.draft = { company: $("#targetCompany")?.value || "", role: $("#targetRole")?.value || "", jd: $("#jdInput")?.value || "" };
    syncWorkspace();
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {
      toast("本地存储空间不足：请删除较大的 PDF 模板或先导出备份");
      return;
    }
    const status = $("#saveStatus");
    if (status) {
      status.textContent = message;
      clearTimeout(persist.timer);
      persist.timer = setTimeout(() => status.textContent = "本地自动保存", 1800);
    }
  }

  function toast(message) {
    const node = $("#toast");
    node.textContent = message;
    node.classList.add("show");
    clearTimeout(toast.timer);
    toast.timer = setTimeout(() => node.classList.remove("show"), 2600);
  }

  function escapeHtml(text = "") {
    return String(text).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  function normalize(text = "") {
    return text.toLowerCase().replace(/\s+/g, "");
  }

  function matchNormalize(text = "") {
    return normalize(text)
      .replace(/[|｜:：,，。；;、【】（）()·/\\\-—–]/g, "")
      .replace(/至今/g, "今")
      .replace(/现居地/g, "");
  }

  function currentTemplate() {
    return state.templates.find(t => t.id === state.activeTemplateId) || state.templates[0];
  }

  function renderTemplates() {
    $("#templateSelect").innerHTML = state.templates.map(t => `<option value="${t.id}">${escapeHtml(t.name)}</option>`).join("");
    $("#templateSelect").value = state.activeTemplateId;
    $("#templateCount").textContent = state.templates.length;
    $("#templateList").innerHTML = state.templates.map(t => `
      <article class="template-item ${t.id === state.activeTemplateId ? "active" : ""}" data-template="${t.id}">
        <b>${escapeHtml(t.name)}</b><small>${new Date(t.updatedAt).toLocaleDateString("zh-CN")} 更新</small>
        <footer><span>${escapeHtml(t.workspace?.userName || "未命名用户")}</span><span><button data-rename="${t.id}">重命名</button><button data-delete-template="${t.id}">删除</button></span></footer>
      </article>`).join("");
  }

  function switchTemplate(id) {
    persist();
    state.activeTemplateId = id;
    activateWorkspaceData(state,id);
    $("#resumeEditor").innerHTML = currentTemplate().html;
    $("#resumeEditor").contentEditable = currentTemplate().type === "pdf" ? "false" : "true";
    $("#targetCompany").value = state.draft.company || "";
    $("#targetRole").value = state.draft.role || "";
    $("#jdInput").value = state.draft.jd || "";
    $("#currentUserName").value = currentTemplate().workspace.userName || "";
    renderTemplates();
    renderVersions(); renderMaterials(); renderProfileEditor(); renderInterview();
    persist("模板已切换");
    if (currentTemplate().type === "docx") loadOriginalDocxModel().then(mapEditorToDocx);
  }

  function renderVersions() {
    const q = normalize($("#versionSearch").value);
    const versions = state.versions.filter(v => normalize(`${v.company}${v.role}${v.createdAt}${v.note}`).includes(q));
    $("#versionCount").textContent = state.versions.length;
    $("#versionList").innerHTML = versions.length ? versions.map(v => `
      <article class="version-item" data-version="${v.id}">
        <div class="meta"><span>${escapeHtml(v.company)} · ${escapeHtml(v.role)}</span><span>${new Date(v.createdAt).toLocaleDateString("zh-CN")}</span></div>
        <b>${escapeHtml(v.note || "未填写备注")}</b>
        <small>${v.plainText.length} 字 · ${v.jd ? "含 JD" : "无 JD"}</small>
        <footer><button data-view="${v.id}">查看/对比</button><button data-rollback="${v.id}">回滚</button><button data-delete-version="${v.id}">删除</button></footer>
      </article>`).join("") : `<div class="version-item"><small>暂无匹配版本</small></div>`;
  }

  function extractKeywords(jd) {
    const normalized = normalize(jd);
    const groups = Object.entries(termGroups).map(([name, aliases]) => {
      const terms = aliases.filter(term => normalized.includes(normalize(term)));
      return { name, terms, weight: Math.max(1, terms.length) };
    }).filter(group => group.terms.length);
    const explicit = jd.match(/[A-Za-z][A-Za-z0-9+#.-]{1,20}|[\u4e00-\u9fa5]{2,8}(?:证书|经验|能力|工具|策划|运营|分析|研究|协作|写作|传播)/g) || [];
    return [...new Set([...groups.flatMap(g => g.terms), ...explicit])].slice(0, 45);
  }

  function analyzeJD() {
    const jd = $("#jdInput").value.trim();
    if (!jd) return toast("请先粘贴岗位 JD");
    const text = normalize($("#resumeEditor").innerText + state.materials.map(m => `${m.keywords}${m.theme}${m.polished}`).join(""));
    const resumeText = normalize($("#resumeEditor").innerText);
    const keywords = extractKeywords(jd);
    const matched = keywords.filter(k => resumeText.includes(normalize(k)));
    const missing = keywords.filter(k => !resumeText.includes(normalize(k)));
    const groups = Object.entries(termGroups).map(([name, aliases]) => {
      const required = aliases.filter(term => normalize(jd).includes(normalize(term)));
      if (!required.length) return null;
      const hit = required.filter(term => text.includes(normalize(term))).length;
      return { name, required, score: Math.round(hit / required.length * 100) };
    }).filter(Boolean);
    const score = keywords.length ? Math.round(matched.length / keywords.length * 100) : 0;
    lastAnalysis = { keywords, matched, missing, groups, score };
    renderAnalysis();
    renderMaterials();
    persist("JD 分析已更新");
  }

  function optimizeResumeFromJD() {
    const jd = $("#jdInput").value.trim();
    if (!jd || lastAnalysis.keywords.length === 0) return;
    const editor = $("#resumeEditor");
    const bullets = $$(".bullet", editor);
    let updated = 0;
    bullets.forEach(node => {
      const original = node.textContent.trim();
      if (!original) return;
      const clean = original.replace(/^【[^】]+】/, "").replace(/[。；;]+$/, "");
      const source = normalize(clean);
      const group = Object.entries(termGroups)
        .map(([name, aliases]) => ({
          name,
          score: aliases.filter(alias => normalize(jd).includes(normalize(alias)) && source.includes(normalize(alias))).length
        }))
        .sort((a,b) => b.score - a.score)[0];
      if (group?.score > 0) {
        const next = `【${group.name}】${clean}。`;
        if (next !== original) { node.textContent = next; updated++; }
      }
    });

    persist(`已按 JD 自动优化 ${updated} 条`);
    toast(`已先按 JD 自动优化简历：按岗位能力重组 ${updated} 条表达`);
  }

  function renderAnalysis() {
    const { matched, missing, groups, score } = lastAnalysis;
    $("#abilityMap").innerHTML = `
      <div class="map-score">
        <div class="score-ring" style="--score:${score * 3.6}deg"><b>${score}%</b></div>
        <div><h3>${score >= 75 ? "匹配良好" : score >= 50 ? "具备基础匹配" : "仍有提升空间"}</h3><p>匹配度仅基于当前简历文字，不代表招聘结果。</p></div>
      </div>
      <div class="map-grid">${groups.map(g => `<div class="map-row"><span>${escapeHtml(g.name)}</span><i><b style="width:${g.score}%"></b></i><strong>${g.score}%</strong></div>`).join("") || "<small>未识别到岗位能力类别</small>"}</div>`;
    $("#matchedCount").textContent = matched.length;
    $("#missingCount").textContent = missing.length;
    $("#matchedKeywords").innerHTML = matched.map(k => `<span>${escapeHtml(k)}</span>`).join("");
    $("#missingKeywords").innerHTML = missing.map(k => `<button data-missing="${escapeHtml(k)}">${escapeHtml(k)}</button>`).join("");
    $("#profileMatchCount").textContent = state.materials.filter(materialMatchesJD).length;
  }

  function materialMatchesJD(material) {
    if (!lastAnalysis.keywords.length) return false;
    const haystack = normalize(`${material.theme}${material.keywords}${material.targetRoles}${material.polished}${material.organization}${material.role}`);
    return lastAnalysis.keywords.some(k => haystack.includes(normalize(k)));
  }

  function materialScore(material) {
    const haystack = normalize(`${material.theme}${material.keywords}${material.targetRoles}${material.polished}${material.organization}${material.role}`);
    const hits = lastAnalysis.keywords.filter(k => haystack.includes(normalize(k))).length;
    return Math.min(99, hits * 12 + (material.evidence ? 12 : 0) + (/内容|品牌|传播|运营|用户/.test(haystack) ? 10 : 0));
  }

  function renderMaterials() {
    const query = normalize($("#materialSearch")?.value || "");
    const filter = $("#materialFilter")?.value || "all";
    let list = state.materials.filter(m => {
      const searchable = normalize(`${m.organization}${m.role}${m.theme}${m.keywords}${m.polished}`);
      return (!query || searchable.includes(query)) &&
        (filter === "all" || filter === "matched" && materialMatchesJD(m) || filter === "evidence" && m.evidence);
    }).sort((a, b) => materialScore(b) - materialScore(a)).slice(0, 80);
    $("#materialCount").textContent = state.materials.length;
    $("#evidenceCount").textContent = state.materials.filter(m => m.evidence).length;
    $("#materialList").innerHTML = list.map(m => {
      const star = starRewrite(m);
      return `<article class="material-card">
        <header><div><b>${escapeHtml(m.organization || "未命名经历")}</b><small>${escapeHtml(m.role || m.category || "")} · ${escapeHtml(m.start || "")}—${escapeHtml(m.end || "")}</small></div><span>${materialScore(m)}</span></header>
        <p>${escapeHtml(m.polished || m.original || "")}</p>
        <div class="tags">${String(m.theme || m.keywords || "").split(/[、,，]/).filter(Boolean).slice(0,4).map(t => `<span>${escapeHtml(t)}</span>`).join("")}${m.evidence ? "<span>含量化结果</span>" : ""}</div>
        <footer><button data-copy="${m.id}">复制</button><button data-insert="${m.id}">插入光标处</button><button class="star" data-star="${m.id}" title="${escapeHtml(star)}">STAR 润色并插入</button></footer>
      </article>`;
    }).join("") || `<div class="material-card"><p>没有符合条件的素材。</p></div>`;
  }

  function renderProfileEditor() {
    const basicFields = [["name","姓名"],["phone","电话"],["email","邮箱"],["city","城市"],["intention","求职意向"],["years","工作年限"]];
    const sections = [
      ["education","教育经历"],
      ["work","工作 / 实习经历"],
      ["projects","项目经历"]
    ];
    $("#profileEditor").innerHTML = `
      <div class="profile-basic-grid">${basicFields.map(([key,label]) => `<label>${label}<input data-basic="${key}" value="${escapeHtml(state.profile.basic[key] || "")}"></label>`).join("")}</div>
      ${sections.map(([key,label]) => `<section class="profile-section"><header><h3>${label}</h3><button data-add-profile="${key}">＋ 新增</button></header><div>${(state.profile[key] || []).map((item,index) => profileRow(key,item,index)).join("") || "<small>暂无记录</small>"}</div></section>`).join("")}
      <section class="profile-section profile-textareas">
        <h3>技能、证书、语言与自我评价</h3>
        <label>技能清单<textarea data-profile-text="skills">${escapeHtml((state.profile.skills || []).join("、"))}</textarea></label>
        <label>证书与语言<textarea data-profile-text="certificates">${escapeHtml((state.profile.certificates || []).join("、"))}</textarea></label>
        <label>自我评价<textarea data-profile-text="evaluation">${escapeHtml(state.profile.evaluation || "")}</textarea></label>
      </section>`;
  }

  function generateInterviewQuestions() {
    const jd = $("#jdInput").value.trim();
    const role = $("#targetRole").value.trim() || "目标岗位";
    const experiences = $$(".line b",$("#resumeEditor")).map(x=>x.textContent.trim()).filter(Boolean).slice(0,6);
    const pAndG = [
      "请讲述一个你设定高目标并最终达成的经历。",
      "请讲述一个你主动带领团队完成困难任务的经历。",
      "请讲述一个你需要快速搜集信息、分析并作出决策的经历。",
      "请讲述一个你用创新方法解决复杂问题的经历。",
      "请讲述一个你与他人产生分歧并推动达成共识的经历。",
      "请讲述一个你影响他人并获得支持的经历。",
      "请讲述一个你同时处理多项重要任务并保证交付的经历。",
      "请讲述一个失败或受挫的经历，你如何复盘并改进？"
    ].map((q,i)=>({id:crypto.randomUUID(),category:"p&g",question:`宝洁八问 ${i+1}｜${q}`,hint:"建议按 STAR：背景与目标—你的具体行动—量化结果—复盘。",answer:""}));
    const groups = lastAnalysis.groups.slice(0,6);
    const business = groups.map(g=>({id:crypto.randomUUID(),category:"business",question:`如果你负责${role}工作，遇到“${g.name}”指标连续两周低于目标，你会如何定位问题并制定行动方案？`,hint:`结合 JD 中的${g.required?.slice(0,3).join("、") || g.name}，说明数据、用户、协作和复盘链路。`,answer:""}));
    const deep = experiences.map(name=>({id:crypto.randomUUID(),category:"deep",question:`请深挖你在“${name}”中的一项代表性成果：目标由谁提出、你具体负责什么、最大的困难是什么、结果如何验证？`,hint:"面试官可能继续追问数据口径、个人贡献、协作对象和替代方案。",answer:""}));
    const jdQuestions = extractKeywords(jd).slice(0,5).map(k=>({id:crypto.randomUUID(),category:"business",question:`JD 强调“${k}”。请用一段真实经历证明你具备这项能力，并说明如果加入团队将如何迁移使用。`,hint:"先给结论，再用一段最匹配经历提供证据。",answer:""}));
    currentTemplate().workspace.interview = [...pAndG,...business,...deep,...jdQuestions];
    renderInterview(); persist("Mock 面试题单已生成");
    toast(`已生成 ${currentTemplate().workspace.interview.length} 道模拟面试题`);
  }

  function renderInterview(filter="all") {
    const list = currentTemplate()?.workspace?.interview || [];
    const shown = filter === "all" ? list : list.filter(q=>q.category===filter);
    $("#interviewProgress").textContent = `${list.filter(q=>q.answer?.trim()).length}/${list.length} 题已作答 · 回答自动保存在当前用户模板`;
    $("#interviewList").innerHTML = shown.length ? shown.map((q,index)=>`<article class="interview-card" data-question="${q.id}">
      <header><b>${index+1}. ${escapeHtml(q.question)}</b><span>${q.category==="p&g"?"宝洁八问":q.category==="business"?"业务情景":"经历深挖"}</span></header>
      <p>${escapeHtml(q.hint)}</p>
      <textarea placeholder="在这里记录你的 STAR 回答……">${escapeHtml(q.answer||"")}</textarea>
      <footer><span>${(q.answer||"").length} 字</span><button data-copy-answer="${q.id}">复制回答</button></footer>
    </article>`).join("") : `<div class="material-card"><p>填写 JD 后点击“生成新题单”。</p></div>`;
  }

  function profileRow(type, item, index) {
    if (type === "education") return `<article class="profile-row" data-profile-row="${type}-${index}">
      <input data-profile-field="school" value="${escapeHtml(item.school || "")}" placeholder="学校">
      <div class="variant-grid"><input data-profile-field="degree" value="${escapeHtml(item.degree || "")}" placeholder="学历"><input data-profile-field="major" value="${escapeHtml(item.major || "")}" placeholder="专业"></div>
      <input data-profile-field="time" value="${escapeHtml(item.time || "")}" placeholder="时间">
      <textarea data-profile-field="detail" placeholder="成绩、排名、课程">${escapeHtml(item.detail || "")}</textarea>
      <button data-remove-profile="${type}-${index}">删除</button></article>`;
    const variants = item.variants || { 通用向:item.description || "", 技术向:"", 产品向:"", 运营向:"" };
    return `<article class="profile-row" data-profile-row="${type}-${index}">
      <input data-profile-field="organization" value="${escapeHtml(item.organization || "")}" placeholder="${type === "work" ? "公司 / 组织" : "项目名称"}">
      <div class="variant-grid"><input data-profile-field="role" value="${escapeHtml(item.role || "")}" placeholder="角色 / 职位"><input data-profile-field="time" value="${escapeHtml(item.time || "")}" placeholder="时间"></div>
      ${Object.entries(variants).map(([name,text]) => `<label>${name}<textarea data-profile-variant="${escapeHtml(name)}">${escapeHtml(text)}</textarea></label>`).join("")}
      <button data-remove-profile="${type}-${index}">删除</button></article>`;
  }

  function starRewrite(material) {
    const source = String(material.polished || material.original || "").trim();
    const colon = source.search(/[：:]/);
    const topic = (material.theme || (colon > 0 ? source.slice(0, colon) : "经历能力")).split(/[、,，/]/)[0].replace(/能力$/, "");
    const detail = colon > 0 ? source.slice(colon + 1).trim() : source;
    const context = material.organization && material.role ? `在${material.organization}担任${material.role}期间，` : "";
    const usableEvidence = /(%|万|千|人|条|次|份|场|家|个|周|月|年|提升|增长|曝光|转化|粉丝|获赞)/.test(material.evidence || "");
    const result = usableEvidence && !detail.includes(material.evidence) ? `，结果达成${material.evidence}` : "";
    return `【${topic}】${context}${detail.replace(/[。；;]+$/, "")}${result}。`;
  }

  function restoreSelection() {
    const editor = $("#resumeEditor");
    editor.focus();
    const selection = window.getSelection();
    selection.removeAllRanges();
    if (selectionRange && editor.contains(selectionRange.commonAncestorContainer)) {
      selection.addRange(selectionRange);
      return selectionRange;
    }
    const walker = document.createTreeWalker(editor, NodeFilter.SHOW_TEXT);
    const last = [...function*(){ let n; while ((n = walker.nextNode())) yield n; }()].pop();
    const range = document.createRange();
    range.selectNodeContents(last || editor);
    range.collapse(false);
    selection.addRange(range);
    return range;
  }

  function insertTextOnly(text) {
    const range = restoreSelection();
    range.deleteContents();
    const node = document.createTextNode(text);
    range.insertNode(node);
    range.setStartAfter(node);
    range.collapse(true);
    const selection = window.getSelection();
    selection.removeAllRanges();
    selection.addRange(range);
    selectionRange = range.cloneRange();
    persist("文字已插入");
    toast("已插入到简历光标位置");
  }

  function suggestLocation(keyword) {
    const suggestions = {
      "AI": "建议在“个人优势”或相关内容经历中补充真实使用场景。",
      "ChatGPT": "建议写明用于检索、构思、修改还是事实核查。",
      "品牌": "优先检查明基 Marcom、活动策划或新媒体经历。",
      "公关": "优先检查活动稿件、媒体协作或对外传播经历。",
      "数据": "优先补充传播曝光、粉丝增长、转化率或内容数量。",
      "证书": "请在教育背景后增加真实持有的证书信息。",
      "经验": "请核对经历时间，禁止推算或扩大年限。"
    };
    const key = Object.keys(suggestions).find(k => keyword.includes(k));
    const matchedMaterials = state.materials.filter(m => normalize(`${m.keywords}${m.theme}${m.polished}`).includes(normalize(keyword))).slice(0,3);
    const materialHint = matchedMaterials.length ? ` 可核对素材：${matchedMaterials.map(m => m.organization).join("、")}。` : "";
    toast((suggestions[key] || `建议在个人优势、技能或最相关经历中核对“${keyword}”的真实证据。`) + materialHint);
  }

  async function parseXlsx(file) {
    const zip = await JSZip.loadAsync(await file.arrayBuffer());
    const sharedFile = zip.file("xl/sharedStrings.xml");
    const shared = sharedFile ? parseSharedStrings(await sharedFile.async("text")) : [];
    const workbookXml = await zip.file("xl/workbook.xml").async("text");
    const relsXml = await zip.file("xl/_rels/workbook.xml.rels").async("text");
    const workbook = new DOMParser().parseFromString(workbookXml, "application/xml");
    const rels = new DOMParser().parseFromString(relsXml, "application/xml");
    const relations = Object.fromEntries($$("Relationship", rels).map(r => [r.getAttribute("Id"), r.getAttribute("Target")]));
    const sheets = $$("sheet", workbook);
    const chosen = sheets.find(s => s.getAttribute("name") === "经历素材库") || sheets[0];
    if (!chosen) throw new Error("未找到工作表");
    const rid = chosen.getAttribute("r:id") || chosen.getAttributeNS("http://schemas.openxmlformats.org/officeDocument/2006/relationships", "id");
    let target = relations[rid];
    if (!target) throw new Error("工作表关系读取失败");
    target = target.startsWith("/") ? target.slice(1) : `xl/${target.replace(/^\.\.\//, "")}`;
    const xml = await zip.file(target).async("text");
    return parseSheet(xml, shared);
  }

  function parseSharedStrings(xml) {
    const doc = new DOMParser().parseFromString(xml, "application/xml");
    return $$("si", doc).map(si => $$("t", si).map(t => t.textContent).join(""));
  }

  function parseSheet(xml, shared) {
    const doc = new DOMParser().parseFromString(xml, "application/xml");
    const rows = $$("sheetData row", doc).map(row => {
      const values = {};
      $$("c", row).forEach(cell => {
        const ref = cell.getAttribute("r") || "";
        const col = ref.replace(/\d/g, "");
        const type = cell.getAttribute("t");
        const inline = $("is t", cell)?.textContent;
        const raw = $("v", cell)?.textContent || "";
        values[col] = type === "s" ? shared[Number(raw)] || "" : type === "inlineStr" ? inline || "" : raw;
      });
      return values;
    });
    if (!rows.length) return [];
    const columns = Object.keys(rows[0]);
    const headers = Object.fromEntries(columns.map(col => [col, rows[0][col]]));
    return rows.slice(1).map(row => Object.fromEntries(columns.map(col => [headers[col], row[col] || ""])));
  }

  function mapImportedRows(rows) {
    if (!rows.length) return [];
    const hasMaterialHeaders = Object.keys(rows[0]).some(h => ["素材ID","润色后素材","原始素材"].includes(h));
    if (hasMaterialHeaders) return rows.filter(r => r["润色后素材"] || r["原始素材"]).map((r, i) => ({
      id: r["素材ID"] || `IMP-${Date.now()}-${i}`,
      experienceId: r["经历ID"] || "",
      category: r["类别"] || "",
      organization: r["组织/项目"] || r["公司"] || "",
      role: r["角色"] || r["职位"] || "",
      start: r["开始时间"] || "",
      end: r["结束时间"] || "",
      theme: r["能力主题"] || "",
      original: r["原始素材"] || "",
      polished: r["润色后素材"] || r["原始素材"] || "",
      evidence: r["量化证据"] || "",
      keywords: r["关键词"] || "",
      targetRoles: r["适配岗位"] || "",
      truth: r["真实性"] || "Excel 导入，待人工核验",
      todo: r["待补充信息"] || "",
      enabled: !["否","0","false"].includes(String(r["启用"]).toLowerCase()),
      source: "用户上传 Excel",
      completeness: r["信息完整度"] || ""
    }));
    return rows.filter(r => Object.values(r).some(Boolean)).map((r, i) => {
      const text = r["描述"] || r["工作内容"] || r["项目内容"] || r["经历描述"] || Object.values(r).filter(Boolean).join("；");
      return { id:`IMP-${Date.now()}-${i}`,experienceId:"",category:r["类别"]||"导入",organization:r["公司"]||r["组织/项目"]||r["学校"]||"",role:r["职位"]||r["角色"]||"",start:r["开始时间"]||"",end:r["结束时间"]||"",theme:r["能力主题"]||"",original:text,polished:text,evidence:r["量化证据"]||"",keywords:r["关键词"]||"",targetRoles:r["适配岗位"]||"",truth:"Excel 导入，待人工核验",todo:"",enabled:true,source:"用户上传 Excel",completeness:""};
    });
  }

  function download(name, blob) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = name; a.click();
    URL.revokeObjectURL(url);
  }

  function fileToBase64(file) {
    return new Promise((resolve,reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result).split(",")[1]);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }
  function base64Blob(base64,type) {
    const bytes = Uint8Array.from(atob(base64),c => c.charCodeAt(0));
    return new Blob([bytes],{type});
  }
  function exportPdf() {
    const template = currentTemplate();
    if (template.type === "pdf" && template.sourceBase64) {
      download(filename("pdf"),base64Blob(template.sourceBase64,"application/pdf"));
      toast("已按原 PDF 模板无损导出");
      return;
    }
    document.title = filename("pdf").replace(".pdf","");
    window.print();
  }

  async function docxToEditableHtml(base64) {
    const zip = await JSZip.loadAsync(base64,{base64:true});
    const xml = await zip.file("word/document.xml").async("text");
    const doc = new DOMParser().parseFromString(xml,"application/xml");
    const relFile = zip.file("word/_rels/document.xml.rels");
    const relDoc = relFile ? new DOMParser().parseFromString(await relFile.async("text"),"application/xml") : null;
    const rels = {};
    if (relDoc) [...relDoc.getElementsByTagName("Relationship")].forEach(r=>rels[r.getAttribute("Id")] = r.getAttribute("Target"));
    const allPs = [...doc.getElementsByTagNameNS("http://schemas.openxmlformats.org/wordprocessingml/2006/main","p")];
    const pIndex = new Map(allPs.map((p,index)=>[p,index]));
    const body = doc.getElementsByTagNameNS("http://schemas.openxmlformats.org/wordprocessingml/2006/main","body")[0];
    const imageCache = {};
    const attr = (node,name) => node?.getAttribute(name) || node?.getAttributeNS("http://schemas.openxmlformats.org/wordprocessingml/2006/main",name) || "";
    const cssPt = twips => `${Math.max(0,Number(twips||0)/20)}pt`;

    async function imageHtml(container) {
      const blips = [...container.getElementsByTagNameNS("http://schemas.openxmlformats.org/drawingml/2006/main","blip")];
      const output = [];
      for (const blip of blips) {
        const id = blip.getAttribute("r:embed") || blip.getAttributeNS("http://schemas.openxmlformats.org/officeDocument/2006/relationships","embed");
        const target = rels[id]; if (!target) continue;
        const path = target.startsWith("/") ? target.slice(1) : `word/${target.replace(/^\.\//,"")}`;
        if (!imageCache[path]) {
          const file = zip.file(path); if (!file) continue;
          const ext = path.split(".").pop().toLowerCase();
          const mime = ext === "png" ? "image/png" : ext === "gif" ? "image/gif" : "image/jpeg";
          imageCache[path] = `data:${mime};base64,${await file.async("base64")}`;
        }
        const extent = container.getElementsByTagNameNS("http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing","extent")[0];
        const width = extent ? Math.round(Number(extent.getAttribute("cx"))/9525) : 120;
        const height = extent ? Math.round(Number(extent.getAttribute("cy"))/9525) : 150;
        output.push(`<img src="${imageCache[path]}" style="width:${width}px;height:${height}px;object-fit:contain">`);
      }
      return output.join("");
    }

    async function paragraphHtml(p) {
      const pPr = [...p.children].find(x=>x.localName==="pPr");
      const jc = pPr?.getElementsByTagNameNS("http://schemas.openxmlformats.org/wordprocessingml/2006/main","jc")[0];
      const spacing = pPr?.getElementsByTagNameNS("http://schemas.openxmlformats.org/wordprocessingml/2006/main","spacing")[0];
      const alignMap = {center:"center",right:"right",both:"justify",left:"left"};
      const styles = [
        `text-align:${alignMap[attr(jc,"val")]||"left"}`,
        `margin-top:${cssPt(attr(spacing,"before"))}`,
        `margin-bottom:${cssPt(attr(spacing,"after"))}`
      ];
      if (attr(spacing,"line")) styles.push(`line-height:${Math.max(.8,Number(attr(spacing,"line"))/240)}`);
      const runs = [...p.getElementsByTagNameNS("http://schemas.openxmlformats.org/wordprocessingml/2006/main","r")];
      let content = "";
      for (const run of runs) {
        const rPr = [...run.children].find(x=>x.localName==="rPr");
        const fonts = rPr?.getElementsByTagNameNS("http://schemas.openxmlformats.org/wordprocessingml/2006/main","rFonts")[0];
        const size = rPr?.getElementsByTagNameNS("http://schemas.openxmlformats.org/wordprocessingml/2006/main","sz")[0];
        const color = rPr?.getElementsByTagNameNS("http://schemas.openxmlformats.org/wordprocessingml/2006/main","color")[0];
        const runStyles = [];
        const font = attr(fonts,"eastAsia") || attr(fonts,"ascii");
        if (font) runStyles.push(`font-family:'${font}'`);
        if (attr(size,"val")) runStyles.push(`font-size:${Number(attr(size,"val"))/2}pt`);
        if (rPr?.getElementsByTagNameNS("http://schemas.openxmlformats.org/wordprocessingml/2006/main","b").length) runStyles.push("font-weight:bold");
        if (rPr?.getElementsByTagNameNS("http://schemas.openxmlformats.org/wordprocessingml/2006/main","i").length) runStyles.push("font-style:italic");
        if (rPr?.getElementsByTagNameNS("http://schemas.openxmlformats.org/wordprocessingml/2006/main","u").length) runStyles.push("text-decoration:underline");
        if (attr(color,"val") && attr(color,"val") !== "auto") runStyles.push(`color:#${attr(color,"val")}`);
        const text = [...run.getElementsByTagNameNS("http://schemas.openxmlformats.org/wordprocessingml/2006/main","t")].map(t=>t.textContent).join("");
        content += `<span style="${runStyles.join(";")}">${escapeHtml(text)}</span>${await imageHtml(run)}`;
      }
      return `<p data-docx-index="${pIndex.get(p)}" data-docx-original="${escapeHtml(p.textContent||"")}" style="${styles.join(";")}">${content || "<br>"}</p>`;
    }
    async function tableHtml(tbl) {
      const rows = [...tbl.children].filter(x=>x.localName==="tr");
      let html = "<table>";
      for (const row of rows) {
        html += "<tr>";
        for (const cell of [...row.children].filter(x=>x.localName==="tc")) {
          html += "<td>";
          for (const child of [...cell.children]) if (child.localName==="p") html += await paragraphHtml(child); else if (child.localName==="tbl") html += await tableHtml(child);
          html += "</td>";
        }
        html += "</tr>";
      }
      return html+"</table>";
    }
    let html = '<div class="docx-imported">';
    for (const child of [...body.children]) {
      if (child.localName === "p") html += await paragraphHtml(child);
      if (child.localName === "tbl") html += await tableHtml(child);
    }
    return html+"</div>";
  }

  function filename(ext) {
    const name = state.profile.basic.name || $("#resumeEditor h1")?.textContent.trim() || "姓名";
    const company = $("#targetCompany").value.trim() || "公司";
    const role = $("#targetRole").value.trim() || "岗位";
    const date = new Date().toISOString().slice(0,10).replaceAll("-","");
    return `${name}-${company}-${role}-${date}.${ext}`;
  }

  async function exportDocx() {
    if (currentTemplate().type === "pdf") return toast("当前为 PDF 模板，请选择导出 PDF");
    if (currentTemplate().type === "docx" && currentTemplate().sourceBase64) {
      return exportOriginalDocx();
    }
    if (!window.docx) return toast("Word 导出组件未加载");
    const { Document, Packer, Paragraph, TextRun, AlignmentType, BorderStyle } = window.docx;
    const children = [];
    [...$("#resumeEditor").children].forEach(node => {
      if (node.matches(".resume-head")) {
        children.push(new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: node.innerText.replace(/\n+/g,"　"), bold: true, size: 28 })], spacing: { after: 180 }, border: { bottom: { color: "222222", style: BorderStyle.SINGLE, size: 12 } } }));
      } else if (node.tagName === "SECTION") {
        [...node.children].forEach(child => {
          if (child.tagName === "H2") children.push(new Paragraph({ children:[new TextRun({ text: child.innerText, bold:true, size:22 })], spacing:{before:180,after:80}, border:{bottom:{color:"555555",style:BorderStyle.SINGLE,size:5}} }));
          else children.push(new Paragraph({ text: child.innerText.replace(/\n+/g,"　"), bullet: child.classList.contains("bullet") ? { level: 0 } : undefined, spacing:{after:45,line:280} }));
        });
      } else children.push(new Paragraph(node.innerText));
    });
    const doc = new Document({ sections: [{ properties: { page: { size: { width: 11906, height: 16838 }, margin: { top: 794, right: 907, bottom: 794, left: 907 } } }, children }] });
    download(filename("docx"), await Packer.toBlob(doc));
    toast("Word 文件已导出");
  }

  async function loadOriginalDocxModel() {
    const template = currentTemplate();
    if (!template?.sourceBase64 || template.type !== "docx") return null;
    if (docxTemplateModel?.templateId === template.id) return docxTemplateModel;
    const zip = await JSZip.loadAsync(template.sourceBase64, { base64:true });
    const xml = await zip.file("word/document.xml").async("text");
    const documentXml = new DOMParser().parseFromString(xml, "application/xml");
    const paragraphs = [...documentXml.getElementsByTagNameNS("http://schemas.openxmlformats.org/wordprocessingml/2006/main", "p")];
    const texts = paragraphs.map(p => [...p.getElementsByTagNameNS("http://schemas.openxmlformats.org/wordprocessingml/2006/main", "t")].map(t => t.textContent).join(""));
    docxTemplateModel = { templateId:template.id, zip, documentXml, paragraphs, texts };
    mapEditorToDocx();
    return docxTemplateModel;
  }

  function mapEditorToDocx() {
    if (!docxTemplateModel || docxTemplateModel.templateId !== state.activeTemplateId) return;
    const elements = $$("h1,h2,p,.line", $("#resumeEditor"));
    const used = new Set();
    elements.forEach(element => {
      const target = matchNormalize(element.textContent);
      if (!target) return;
      let best = { index:-1, score:0 };
      docxTemplateModel.texts.forEach((text,index) => {
        if (used.has(index)) return;
        const source = matchNormalize(text);
        if (!source) return;
        let score = 0;
        if (source === target) score = 1;
        else if (source.includes(target) || target.includes(source)) score = Math.min(source.length,target.length) / Math.max(source.length,target.length);
        else {
          const chars = new Set(target);
          const common = [...new Set(source)].filter(char => chars.has(char)).length;
          score = common / Math.max(new Set(source).size, chars.size);
        }
        if (score > best.score) best = { index, score };
      });
      if (best.score >= .48) {
        element.dataset.docxIndex = String(best.index);
        if (!element.dataset.docxOriginal) element.dataset.docxOriginal = element.textContent.trim();
        used.add(best.index);
      }
    });
    if (!currentTemplate().docxMappedIndices) currentTemplate().docxMappedIndices = elements.map(el=>el.dataset.docxIndex).filter(Boolean);
  }

  async function exportOriginalDocx() {
    const model = await loadOriginalDocxModel();
    if (!model) return toast("原始 Word 模板未加载");
    const zip = await JSZip.loadAsync(currentTemplate().sourceBase64, { base64:true });
    const xml = await zip.file("word/document.xml").async("text");
    const documentXml = new DOMParser().parseFromString(xml, "application/xml");
    const paragraphs = [...documentXml.getElementsByTagNameNS("http://schemas.openxmlformats.org/wordprocessingml/2006/main", "p")];
    let replacements = 0;
    const presentIndices = new Set($$("[data-docx-index]",$("#resumeEditor")).map(el=>el.dataset.docxIndex));
    (currentTemplate().docxMappedIndices || []).forEach(index => {
      if (presentIndices.has(String(index))) return;
      const paragraph = paragraphs[Number(index)]; if (!paragraph) return;
      [...paragraph.getElementsByTagNameNS("http://schemas.openxmlformats.org/wordprocessingml/2006/main","t")].forEach(node=>node.textContent="");
      replacements++;
    });
    $$("[data-docx-index]", $("#resumeEditor")).forEach(element => {
      const paragraph = paragraphs[Number(element.dataset.docxIndex)];
      if (!paragraph) return;
      const textNodes = [...paragraph.getElementsByTagNameNS("http://schemas.openxmlformats.org/wordprocessingml/2006/main", "t")];
      if (!textNodes.length) return;
      const nextText = element.textContent.trim();
      const originalEditorText = element.dataset.docxOriginal || textNodes.map(node => node.textContent).join("").trim();
      if (matchNormalize(nextText) === matchNormalize(originalEditorText)) return;
      textNodes[0].textContent = nextText;
      textNodes.slice(1).forEach(node => node.textContent = "");
      replacements++;
    });
    $$("[data-docx-new]",$("#resumeEditor")).forEach(element => {
      const after = paragraphs[Number(element.dataset.docxAfter)]; if (!after) return;
      const clone = after.cloneNode(true);
      const textNodes=[...clone.getElementsByTagNameNS("http://schemas.openxmlformats.org/wordprocessingml/2006/main","t")];
      if (!textNodes.length) return;
      textNodes[0].textContent=element.textContent.trim(); textNodes.slice(1).forEach(node=>node.textContent="");
      after.parentNode.insertBefore(clone,after.nextSibling); replacements++;
    });
    zip.file("word/document.xml", new XMLSerializer().serializeToString(documentXml));
    const blob = await zip.generateAsync({ type:"blob", mimeType:"application/vnd.openxmlformats-officedocument.wordprocessingml.document", compression:"DEFLATE" });
    download(filename("docx"), blob);
    toast(`已基于原模板导出：保留页面与格式，仅替换 ${replacements} 处文字`);
  }

  function saveVersion(note) {
    const company = $("#targetCompany").value.trim();
    const role = $("#targetRole").value.trim();
    if (!company || !role) { toast("请先补全目标公司和目标岗位"); return false; }
    persist();
    const version = {
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
      company, role,
      jd: $("#jdInput").value,
      html: $("#resumeEditor").innerHTML,
      plainText: $("#resumeEditor").innerText,
      note: note || ""
    };
    state.versions.unshift(version);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    renderVersions();
    toast("岗位版本已保存");
    return true;
  }

  function lineDiff(a, b) {
    const oldLines = a.split(/\n/).map(s => s.trim()).filter(Boolean);
    const newLines = b.split(/\n/).map(s => s.trim()).filter(Boolean);
    const oldSet = new Set(oldLines), newSet = new Set(newLines);
    return {
      oldHtml: oldLines.map(l => `<div class="${newSet.has(l) ? "" : "diff-del"}">${escapeHtml(l)}</div>`).join(""),
      newHtml: newLines.map(l => `<div class="${oldSet.has(l) ? "" : "diff-add"}">${escapeHtml(l)}</div>`).join("")
    };
  }

  function showVersion(id) {
    activeVersionId = id;
    const v = state.versions.find(item => item.id === id);
    const diff = lineDiff(v.plainText, $("#resumeEditor").innerText);
    $("#diffContent").innerHTML = `<div class="version-actions"><button id="exportOneVersion">导出此版本 JSON</button><button id="comparePrevious">与当前版本对比</button></div>
      <p><b>${escapeHtml(v.company)} · ${escapeHtml(v.role)}</b>　${new Date(v.createdAt).toLocaleString("zh-CN")}　${escapeHtml(v.note)}</p>
      <div class="diff-columns"><article><b>保存版本</b><pre>${diff.oldHtml}</pre></article><article><b>当前版本</b><pre>${diff.newHtml}</pre></article></div>`;
    $("#diffDialog").showModal();
  }

  function exportBackup(payload = state, name = `简历工作台备份-${new Date().toISOString().slice(0,10)}.json`) {
    download(name, new Blob([JSON.stringify(payload, null, 2)], { type:"application/json;charset=utf-8" }));
  }

  function bindEvents() {
    $("#resumeEditor").addEventListener("input", () => {
      clearTimeout(persist.editTimer);
      persist.editTimer = setTimeout(() => persist(), 350);
    });
    $("#resumeEditor").addEventListener("beforeinput", e => {
      if (currentTemplate().type === "pdf") {
        e.preventDefault();
        toast("PDF 为固定底图，请上传对应 Word 原稿进行正文排版");
      }
    });
    $("#resumeEditor").addEventListener("paste", e => {
      e.preventDefault();
      document.execCommand("insertText", false, e.clipboardData.getData("text/plain").replace(/\s*\n+\s*/g, " "));
    });
    ["keyup","mouseup","focus"].forEach(type => $("#resumeEditor").addEventListener(type, () => {
      const selection = window.getSelection();
      if (selection.rangeCount && $("#resumeEditor").contains(selection.anchorNode)) selectionRange = selection.getRangeAt(0).cloneRange();
    }));
    $$(".format-tools [data-format]").forEach(button => button.addEventListener("click", () => {
      restoreSelection(); document.execCommand(button.dataset.format,false,null); persist("排版已更新");
    }));
    $("#fontFamily").addEventListener("change", e => { restoreSelection(); document.execCommand("fontName",false,e.target.value); persist("字体已更新"); });
    $("#fontSize").addEventListener("change", e => { restoreSelection(); document.execCommand("fontSize",false,e.target.value); persist("字号已更新"); });
    $("#lineHeight").addEventListener("change", e => {
      const selection=window.getSelection(); const el=selection.anchorNode?.nodeType===3?selection.anchorNode.parentElement:selection.anchorNode;
      const block=el?.closest("p,div,li"); if(block&&$("#resumeEditor").contains(block)){block.style.lineHeight=e.target.value;persist("行距已更新");}
    });
    $("#addParagraph").addEventListener("click", () => {
      const range=restoreSelection(); const p=document.createElement("p"); p.textContent="新增段落"; range.collapse(false);
      const block=range.startContainer.nodeType===3?range.startContainer.parentElement:range.startContainer;
      const currentBlock=block.closest("p,div,li"); if(currentBlock&&currentBlock!==$("#resumeEditor")){p.dataset.docxNew="1";p.dataset.docxAfter=currentBlock.dataset.docxIndex||"";currentBlock.after(p);} else $("#resumeEditor").appendChild(p); selectionRange=null; persist("段落已新增");
    });
    $("#deleteParagraph").addEventListener("click", () => {
      const selection=window.getSelection(); const el=selection.anchorNode?.nodeType===3?selection.anchorNode.parentElement:selection.anchorNode;
      const block=el?.closest("p,.line"); if(block&&$("#resumeEditor").contains(block)&&confirm("确认删除当前段落？")){block.remove();selectionRange=null;persist("段落已删除");}
    });
    $("#templateSelect").addEventListener("change", e => switchTemplate(e.target.value));
    $("#templateList").addEventListener("click", e => {
      const rename = e.target.closest("[data-rename]");
      if (rename) {
        e.stopPropagation();
        const t = state.templates.find(x => x.id === rename.dataset.rename);
        const name = prompt("模板名称", t.name);
        if (name?.trim()) { t.name = name.trim(); renderTemplates(); persist("模板已重命名"); }
        return;
      }
      const remove = e.target.closest("[data-delete-template]");
      if (remove) {
        e.stopPropagation();
        if (state.templates.length === 1) return toast("至少需要保留一个模板");
        const template = state.templates.find(x => x.id === remove.dataset.deleteTemplate);
        if (!confirm(`确认删除模板“${template.name}”及其独立信息库、历史版本和面试记录？`)) return;
        state.templates = state.templates.filter(x => x.id !== template.id);
        if (state.activeTemplateId === template.id) {
          state.activeTemplateId = state.templates[0].id;
          activateWorkspaceData(state,state.activeTemplateId);
          $("#resumeEditor").innerHTML = currentTemplate().html;
          $("#resumeEditor").contentEditable = currentTemplate().type === "pdf" ? "false" : "true";
          $("#targetCompany").value = state.draft.company || "";
          $("#targetRole").value = state.draft.role || "";
          $("#jdInput").value = state.draft.jd || "";
          $("#currentUserName").value = currentTemplate().workspace.userName || "";
        }
        renderTemplates(); renderVersions(); renderMaterials(); renderProfileEditor(); renderInterview(); persist("模板已删除");
        return;
      }
      const item = e.target.closest("[data-template]");
      if (item) switchTemplate(item.dataset.template);
    });
    $("#newTemplateBtn").addEventListener("click", () => {
      const name = prompt("新模板名称", "我的简历模板");
      if (!name?.trim()) return;
      persist();
      const id = crypto.randomUUID();
      state.templates.push({ id, name:name.trim(), type:"html", html:defaultTemplate, originalHtml:defaultTemplate, updatedAt:new Date().toISOString(), workspace:{userName:"",profile:blankProfile(),materials:[],versions:[],draft:{company:"",role:"",jd:""},interview:[]} });
      switchTemplate(id);
    });
    $("#templateUpload").addEventListener("change", async e => {
      const file = e.target.files[0]; if (!file) return;
      try {
        const ext = file.name.split(".").pop().toLowerCase();
        const id = crypto.randomUUID();
        let importedHtml = "", sourceBase64 = "", type = ext;
        if (ext === "html" || ext === "htm") {
          const doc = new DOMParser().parseFromString(await file.text(), "text/html");
          $$("script,link,iframe,object", doc).forEach(n => n.remove());
          const imported = doc.querySelector("main,article,.resume") || doc.body;
          importedHtml = $$("head style", doc).map(style => style.outerHTML).join("") + imported.innerHTML;
          type = "html";
        } else if (ext === "docx") {
          sourceBase64 = await fileToBase64(file);
          importedHtml = await docxToEditableHtml(sourceBase64);
          type = "docx";
        } else if (ext === "pdf") {
          sourceBase64 = await fileToBase64(file);
          importedHtml = `<div class="pdf-overlay-note">PDF 原页面作为不可变底图保存。可在信息库与面试区继续使用；如需修改正文，建议同时上传对应 Word 原稿。</div><embed class="pdf-template-view" src="data:application/pdf;base64,${sourceBase64}" type="application/pdf">`;
          type = "pdf";
        } else throw new Error("仅支持 HTML、DOCX、PDF");
        state.templates.push({ id, name:file.name.replace(/\.[^.]+$/,""), type, sourceBase64, html:importedHtml, originalHtml:importedHtml, updatedAt:new Date().toISOString(), workspace:{userName:"",profile:blankProfile(),materials:[],versions:[],draft:{company:"",role:"",jd:""},interview:[]} });
        switchTemplate(id);
        if (type === "docx") await loadOriginalDocxModel();
        toast(`${file.name} 已创建为独立用户模板`);
      } catch (err) { toast(`模板导入失败：${err.message}`); }
      e.target.value = "";
    });
    $("#undoTextBtn").addEventListener("click", () => {
      if (!confirm("确认恢复为此模板最初导入时的文字？当前未保存修改会丢失。")) return;
      $("#resumeEditor").innerHTML = currentTemplate().originalHtml;
      if (state.activeTemplateId === "tpl-default") mapEditorToDocx();
      persist("模板文字已恢复");
    });
    $("#fullscreenBtn").addEventListener("click", () => document.body.classList.toggle("focus"));
    $$(".right-tabs button").forEach(btn => btn.addEventListener("click", () => {
      $$(".right-tabs button").forEach(b => b.classList.toggle("active", b === btn));
      $$(".right-panel").forEach(p => p.classList.remove("active"));
      $(`#${btn.dataset.tab}Panel`).classList.add("active");
    }));
    $("#analyzeBtn").addEventListener("click", () => { analyzeJD(); optimizeResumeFromJD(); });
    $("#jdInput").addEventListener("input", () => {
      clearTimeout(jdOptimizationTimer);
      jdOptimizationTimer = setTimeout(() => { analyzeJD(); optimizeResumeFromJD(); }, 700);
    });
    $("#missingKeywords").addEventListener("click", e => { if (e.target.dataset.missing) suggestLocation(e.target.dataset.missing); });
    $("#materialSearch").addEventListener("input", renderMaterials);
    $("#materialFilter").addEventListener("change", renderMaterials);
    $("#materialList").addEventListener("mousedown", e => e.preventDefault());
    $("#materialList").addEventListener("click", async e => {
      const id = e.target.dataset.copy || e.target.dataset.insert || e.target.dataset.star;
      if (!id) return;
      const m = state.materials.find(x => x.id === id);
      const text = e.target.dataset.star ? starRewrite(m) : (m.polished || m.original);
      if (e.target.dataset.copy) { await navigator.clipboard.writeText(text); toast("已复制素材"); }
      else insertTextOnly(text);
    });
    $("#profileEditor").addEventListener("input", e => {
      if (e.target.dataset.basic) state.profile.basic[e.target.dataset.basic] = e.target.value;
      if (e.target.dataset.profileText) {
        const key = e.target.dataset.profileText;
        state.profile[key] = key === "evaluation" ? e.target.value : e.target.value.split(/[、,，\n]/).map(x => x.trim()).filter(Boolean);
      }
      const row = e.target.closest("[data-profile-row]");
      if (row) {
        const [type,indexText] = row.dataset.profileRow.split("-");
        const item = state.profile[type][Number(indexText)];
        if (e.target.dataset.profileField) item[e.target.dataset.profileField] = e.target.value;
        if (e.target.dataset.profileVariant) (item.variants ||= {})[e.target.dataset.profileVariant] = e.target.value;
      }
      clearTimeout(persist.profileTimer);
      persist.profileTimer = setTimeout(() => persist("个人信息已保存"), 350);
    });
    $("#profileEditor").addEventListener("click", e => {
      if (e.target.dataset.addProfile) {
        const type = e.target.dataset.addProfile;
        state.profile[type].push(type === "education" ? {school:"",degree:"",major:"",time:"",detail:""} : {organization:"",role:"",time:"",variants:{通用向:"",技术向:"",产品向:"",运营向:""}});
        renderProfileEditor(); persist("已新增个人信息");
      }
      if (e.target.dataset.removeProfile) {
        const [type,indexText] = e.target.dataset.removeProfile.split("-");
        if (confirm("确认删除这条个人信息？")) { state.profile[type].splice(Number(indexText),1); renderProfileEditor(); persist("个人信息已删除"); }
      }
    });
    $("#currentUserName").addEventListener("input", e => {
      currentTemplate().workspace.userName = e.target.value;
      renderTemplates(); persist("用户名称已保存");
    });
    $("#generateInterview").addEventListener("click", () => {
      if (!$("#jdInput").value.trim()) return toast("请先填写岗位 JD");
      analyzeJD(); generateInterviewQuestions();
    });
    $(".interview-filters").addEventListener("click", e => {
      const filter = e.target.dataset.interviewFilter;
      if (!filter) return;
      $$(".interview-filters button").forEach(b=>b.classList.toggle("active",b===e.target));
      renderInterview(filter);
    });
    $("#interviewList").addEventListener("input", e => {
      const card = e.target.closest("[data-question]");
      if (!card || e.target.tagName !== "TEXTAREA") return;
      const q = currentTemplate().workspace.interview.find(x=>x.id===card.dataset.question);
      q.answer = e.target.value;
      card.querySelector("footer span").textContent = `${q.answer.length} 字`;
      clearTimeout(persist.interviewTimer);
      persist.interviewTimer=setTimeout(()=>persist("面试回答已保存"),300);
    });
    $("#interviewList").addEventListener("click", async e => {
      if (!e.target.dataset.copyAnswer) return;
      const q=currentTemplate().workspace.interview.find(x=>x.id===e.target.dataset.copyAnswer);
      await navigator.clipboard.writeText(q.answer||""); toast("回答已复制");
    });
    $("#excelUpload").addEventListener("change", async e => {
      const file = e.target.files[0]; if (!file) return;
      try {
        exportBackup(state, `Excel覆盖前自动备份-${new Date().toISOString().slice(0,10)}.json`);
        const imported = mapImportedRows(await parseXlsx(file));
        if (!imported.length) throw new Error("没有可导入的经历记录");
        if (!confirm(`识别到 ${imported.length} 条素材。确认覆盖当前 ${state.materials.length} 条个人信息素材吗？`)) return;
        state.materials = imported;
        persist("Excel 信息库已覆盖");
        renderMaterials(); analyzeJD();
        toast(`已用 Excel 覆盖为 ${imported.length} 条素材`);
      } catch (err) { toast(`Excel 导入失败：${err.message}`); }
      e.target.value = "";
    });
    $("#saveVersionBtn").addEventListener("click", () => {
      if (!$("#targetCompany").value.trim() || !$("#targetRole").value.trim()) return toast("请先补全目标公司和目标岗位");
      $("#versionDialog").showModal();
    });
    $("#confirmSaveVersion").addEventListener("click", e => {
      e.preventDefault();
      if (saveVersion($("#versionNote").value.trim())) { $("#versionNote").value = ""; $("#versionDialog").close(); }
    });
    $("#versionSearch").addEventListener("input", renderVersions);
    $("#versionList").addEventListener("click", e => {
      const view = e.target.dataset.view, rollback = e.target.dataset.rollback, del = e.target.dataset.deleteVersion;
      if (view) showVersion(view);
      if (rollback) {
        const v = state.versions.find(x => x.id === rollback);
        if (confirm(`确认回滚到 ${v.company} · ${v.role} 的版本？当前内容将先自动保存为一个快照。`)) {
          saveVersion("回滚前自动快照");
          $("#resumeEditor").innerHTML = v.html;
          $("#targetCompany").value = v.company; $("#targetRole").value = v.role; $("#jdInput").value = v.jd;
          persist("历史版本已恢复"); analyzeJD();
        }
      }
      if (del && confirm("确认删除此历史版本？该操作不可撤销。")) { state.versions = state.versions.filter(x => x.id !== del); persist("版本已删除"); renderVersions(); }
    });
    $("#closeDiff").addEventListener("click", () => $("#diffDialog").close());
    $("#diffContent").addEventListener("click", e => {
      if (e.target.id === "exportOneVersion") {
        const v = state.versions.find(x => x.id === activeVersionId);
        exportBackup(v, `${v.company}-${v.role}-版本.json`);
      }
    });
    $("#backupExport").addEventListener("click", () => exportBackup());
    $("#backupImport").addEventListener("change", async e => {
      try {
        const incoming = JSON.parse(await e.target.files[0].text());
        if (!incoming.templates || !incoming.versions) throw new Error();
        if (!confirm("导入将覆盖当前全部模板、信息库和历史版本，是否继续？")) return;
        Object.keys(state).forEach(k => delete state[k]); Object.assign(state, incoming);
        localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); location.reload();
      } catch { toast("备份文件格式无效"); }
    });
    $("#exportBtn").addEventListener("click", () => $("#exportPopover").classList.toggle("open"));
    $("#exportPopover").addEventListener("click", e => {
      if (e.target.dataset.export === "docx") exportDocx();
      if (e.target.dataset.export === "pdf") exportPdf();
      $("#exportPopover").classList.remove("open");
    });
    document.addEventListener("click", e => { if (!e.target.closest(".export-menu")) $("#exportPopover").classList.remove("open"); });
    ["targetCompany","targetRole"].forEach(id => $(`#${id}`).addEventListener("input", () => persist()));
  }

  function init() {
    $("#resumeEditor").innerHTML = currentTemplate().html;
    $("#resumeEditor").contentEditable = currentTemplate().type === "pdf" ? "false" : "true";
    $("#targetCompany").value = state.draft.company || "";
    $("#targetRole").value = state.draft.role || "";
    $("#jdInput").value = state.draft.jd || "";
    $("#currentUserName").value = currentTemplate().workspace?.userName || "";
    renderTemplates();
    renderVersions();
    renderMaterials();
    renderProfileEditor();
    renderInterview();
    bindEvents();
    loadOriginalDocxModel();
    if ($("#jdInput").value.trim()) { analyzeJD(); optimizeResumeFromJD(); }
  }

  init();
})();
